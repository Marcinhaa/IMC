package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edtMassa;
    EditText edtAltura;
    Button btnVerificar;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        carregaComponentes();
        configurarBotaoVerificar();
    }

    protected void carregaComponentes() {
        edtMassa = findViewById(R.id.edtMassa);
        edtAltura = findViewById(R.id.edtAltura);
        btnVerificar = findViewById(R.id.btnVerificar);
        txtResultado = findViewById(R.id.txtResultado);
    }

    protected void configurarBotaoVerificar() {
        btnVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String resultado = realizaCalculo();
                exibiResultado(resultado);
                limpaCampos();
            }
        });
    }

    protected String realizaCalculo() {
        float massa = Float.parseFloat(edtMassa.getText().toString());
        float altura = Float.parseFloat(edtAltura.getText().toString());
        float imc = massa / (altura * altura);
        String resultado = "Não foi possivel calcular o IMC";

        if (imc < 16) {
            resultado = "Magreza grave";
        }
        if (imc >= 16 && imc < 17) {
            resultado = "Magreza moderada";
        }
        if (imc >= 17 && imc < 18.5) {
            resultado = "Magreza leve";
        }
        if (imc >= 18.5 && imc < 25) {
            resultado = "Saudável";
        }
        if (imc >= 25 && imc < 30) {
            resultado = "Sobrepeso";
        }
        if (imc >= 30 && imc < 35) {
            resultado = "Obesidade I";
        }
        if (imc >= 35 && imc < 40) {
            resultado = "Obesidade II";
        }
        if (imc >= 40) {
            resultado = "Obesidade III";
        }
        return resultado;
    }


    protected void exibiResultado(String resultado) {
        txtResultado.setText(resultado);
    }

    protected void limpaCampos() {
        edtMassa.setText("");
        edtAltura.setText("");
    }

}